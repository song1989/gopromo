package banyanConstant

const (
	TypeSet  = "set"
	TypeHset = "hset"
	TypeZset = "zset"
)

//活动空间
const (
	NameSpaceInPromo = "in_promo"
)

//表明
const (
	TableDeftab = "deftab" //测试表
)
